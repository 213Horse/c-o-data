@echo on
setlocal
echo ==========================================
echo    Che do DEBUG: Kiem tra loi Windows
echo ==========================================

:: Check Python
where python
python --version
where python3
python3 --version
where py
py -3 --version

:: Check directory
dir

:: Check venv
if exist venv (
    echo [INFO] Thu muc venv ton tai.
    if exist venv\Scripts\activate.bat (
        echo [INFO] venv\Scripts\activate.bat ton tai.
    ) else (
        echo [LOI] venv\Scripts\activate.bat KHONG ton tai. Co the ban dang dung venv cua Mac/Linux?
    )
) else (
    echo [INFO] Thu muc venv chua duoc tao.
)

:: Try to run the main logic and keep window open
pause
echo Dang thu kich hoat venv...
call venv\Scripts\activate
echo Dang thu cai dat dependencies...
pip install -r requirements.txt
echo Dang thu chay gui_cao.py...
python gui_cao.py

echo ------------------------------------------
echo Ket thuc DEBUG.
pause
